Installation:

Warning: MAKE SURE YOUR READER IS AT LEAST 75% CHARGED before starting installation!!!

1) Connect your reader to the PC
2) Double-click the setup.exe on the PC. The program will give you all necessary instructions on your PC screen.


Linux / MacOS users

You will need Windows for the first installation. 
Subsequent updates could be installed by simply unpacking update.zip to internal memory and rebooting the reader.