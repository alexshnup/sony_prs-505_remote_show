Installation

MAKE SURE YOUR READER IS CHARGED before starting installation!!!

1) Install base image. (Skip this step if you've already done it before)
1.1) Unpack PRSP_600_base_flasher_1.0_by_amutin.zip on your PC
1.2) Vista/Win7 users: disable UAC  (read here how to http://www.howtogeek.com/howto/windows-vista/enable-or-disable-uac-from-the-windows-vista-command-line/ )
1.3) Connect your PRS 600 to your PC
1.4) run runme.bat (doubleclick it)
1.5) Sony's standard flasher UI will show up (that's why you need to disable UAC, this installer modifies Sony's, to install custom image)
1.6) Follow instructions on the screen.

Note: don't forget to restore UAC.

2) Install the update
2.1) Unpack PRSPInstaller folder from this archive to the root of the internal memory of the reader.
2.2) Restart the reader (there is no installer UI), installer will do all necessary steps during startap (invisible to the user, takes a couple of seconds).
2.3) Delete PRSPInstaller folder from internal memory (if it is still there :))



Linux / MacOS users

You will need Windows for the first installation. 
Subsequent updates could be installed by simply unpacking ...update.zip to internal memory and rebooting the reader.